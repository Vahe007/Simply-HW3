import express from "express";
import fs from "fs/promises";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import { getData } from "./helpers.js";
import cors from 'cors';


const app = express();
app.use(cors({origin: "*"}));
app.use(express.json());


// app.use(express.urlencoded({encoded: false}));


const port = 9000;
const __dirname = path.resolve();
// app.use("/todos", express.static(__dirname + "/index.html"));

app.post("/todos", async (req, res) => {
    const dataArr = await getData();

    const data = req.body;
    data.id = uuidv4();
    
    const createdAt = new Date();
    data.createdAt = createdAt;

    const timeInterval = Date.parse((data.deadline)) - data.createdAt;
    console.log(timeInterval);
    setTimeout(() => {
        console.log(`Time for ${data.title} is running out`);
    }, timeInterval);
    dataArr.push(data);
    fs.writeFile(
        __dirname + "/db/config.json",
        JSON.stringify(dataArr, undefined, 2),
        (err) => {
          if (err) throw err;
        }
    );

});

app.get("/todos", async (req, res) => {
    const data = await getData();
    console.log(data);

    res.status(201).send(data);

});


app.put("/todos", async (req, res) => {
  const given = req.body;
  const dataArr = await getData();

    const changedObj = dataArr.find((obj, index) => {
      return obj.id === given.id;
    });
    const id = changedObj.id;
    const newArr = dataArr.filter((obj, index) => {
      return id !== obj.id;
    });

    for (let prop in given) {
      if (given[prop] !== "") {
        changedObj[prop] = given[prop];
      }
    }

    newArr.push(changedObj);

    fs.writeFile(
      __dirname + "/db/config.json",
      JSON.stringify(newArr, undefined, 2),
      (err) => {
        if (err) return err;
      }
    );

});

app.delete("/todos", async (req, res) => {
    let dataArr = await getData();
    const id = req.body.id;
    dataArr = dataArr.filter((data, index) => {
        return data.id !== id;
    });
    fs.writeFile(__dirname + "/db/config.json", JSON.stringify(dataArr, undefined, 2), (err) => {
        if (err) return err;
    }
    );
});




app.listen(port);

