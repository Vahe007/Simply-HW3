import path from "path";
import fs from "fs/promises";

const __dirname = path.resolve();


export const getData = async () => {
    const data = await fs.readFile(`${__dirname}/db/config.json`, "utf-8");
    return JSON.parse(data);
}

export const alert = () => {
    const dataArr = getData();
}
