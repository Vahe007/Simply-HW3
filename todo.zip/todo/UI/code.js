import { BASE_URL } from "./constants.js";

const btn = document.querySelector(".btn");
const changeBtn = document.querySelector(".change");
window.addEventListener("load", () => {
  showData();
})

const getData = async (endpoint) => {
  const response = await fetch(`${BASE_URL}${endpoint}`);
  return response.json();
};

function init() {
  const header = document.querySelector(".header");
  const title = document.querySelector(".title");
  const deadline = document.querySelector(".deadline");
  const completed = document.querySelector(".completed");

  if (!title.value || !deadline.value || !completed.value) {
    header.innerHTML = "Fill out all the blanks";
    setTimeout(() => {
      header.innerHTML = "ToDo List";
    }, 2000);
  } else {
    const data = {
      title: title.value,
      deadline: deadline.value,
      completed: completed.value,
    };
    fetch(`${BASE_URL}todos`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    btn.textContent = "Task is added to the list";
    setTimeout(() => {
      btn.textContent = "Add a new task";
    }, 2000);

    title.value = "";
    deadline.value = "";
    completed.value = "";
    window.location.reload();
  }
}

async function change() {
  const id = document.querySelector(".id");
  const title = document.querySelector(".title2");
  const deadline = document.querySelector(".deadline2");
  const completed = document.querySelector(".completed2");
  const header = document.querySelector(".header2");

  const dataArr = await getData("todos");
  const flag = dataArr.find((data) => {
    return data.id === id.value;
  });
  if (
    !flag ||
    !id.value ||
    (!title.value && !deadline.value && !completed.value)
  ) {
    header.innerHTML = "Inappropriate ID or missing data,  try again";
    setTimeout(() => {
      header.innerHTML =
        "Insert an id and the data of a task you need to be changed";
    }, 1500);
  } else {
    const newData = {
      id: id.value,
      title: title.value,
      deadline: deadline.value,
      completed: completed.value,
    };

    fetch(`${BASE_URL}todos`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newData),
    });
    window.location.reload();
  }
  id.value = "";
  title.value = "";
  deadline.value = "";
  completed.value = "";
}

function showData() {
  const tasks = document.querySelector(".tasks");
  getData("todos").then((data) => {
    data.forEach((task, index) => {
      const taskDiv = document.createElement("div");
      taskDiv.classList.add("task");
      const values = Object.values(task);
      for (let i = 0; i < 3; i++) {
        const text = document.createElement("text");
        text.innerHTML = values[i];
        taskDiv.append(text);
      }
      const deleteBtn = document.createElement("button");
      const changeBtn = document.createElement("button");

      deleteBtn.setAttribute("id", task.id);
      deleteBtn.className = "delete";
      deleteBtn.innerHTML = "X";

      changeBtn.className = "change";
      changeBtn.innerHTML = "";

      deleteBtn.addEventListener("click", (e) => {
        fetch(`${BASE_URL}todos`, {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ id: e.target.id }),
        });
        window.location.reload();
      });
      taskDiv.append(deleteBtn);
      tasks.append(taskDiv);
    });
  });
}

btn.addEventListener("click", (e) => {
  e.preventDefault();
  init();
});
changeBtn.addEventListener("click", () => {
  change();
});

// function remainder() {
//   const remainder = document.querySelector(".remainder");
//   getData("todos").then((dataArr) => {
//     dataArr.forEach((data) => {
//       const timeInterval = Date.parse(data.deadline) - data.createdAt;
//       const id = setTimeout(() => {
//         remainder.classList.add("remainder");
//         remainder.innerHTML = `Time for ${data.title} is running out`;
//         setTimeout(() => {
//           remainder.classList.add("remainder-none");
//         }, 3500);
//         console.log("Its time to do " + data.title);
//       }, timeInterval);
//       console.log(timeInterval);
//     });
//   });
// }



